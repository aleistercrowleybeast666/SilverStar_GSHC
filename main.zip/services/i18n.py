from __future__ import annotations

from enum import Enum
from dataclasses import dataclass
from typing import Any, Mapping

from PySide6.QtCore import QSettings


class Language(str, Enum):
    ZH_CN = "zh_CN"
    EN_US = "en_US"


@dataclass(frozen=True)
class EnumParam:
    namespace: str
    canonical_name: str


ZH_CN: dict[str, str] = {
    "app.title": "二代飞控地面站",
    "language.label": "语言 / Language：",
    "page.preflight": "预飞行",
    "page.flight": "飞行",
    "page.post_process": "后期处理",
    "camera.unlock": "解锁视角",
    "camera.lock": "锁定视角",
    "camera.reset": "重置视角",
    "group.connection": "PC ↔ 地面站串口连接",
    "group.system": "系统",
    "group.calibration": "校准",
    "group.alignment": "初对准",
    "group.sensor_preflight": "传感器数据（PREFLIGHT_STATE）",
    "group.gnss": "GNSS",
    "group.preflight_commands": "预飞任务操作",
    "group.important_status": "重要状态",
    "group.current_data": "当前数据",
    "group.event_history": "事件历史（最近 200 条；JSONL 保留全部）",
    "group.live_plots": "实时曲线（最近 {seconds:g} 秒）",
    "group.post_process": "后期处理（完整数据始终从 JSONL 读取）",
    "field.port": "端口",
    "field.baudrate": "波特率",
    "field.lifecycle": "生命周期",
    "field.system_ready": "系统就绪",
    "field.selftest": "自检",
    "field.capability": "能力信息",
    "field.air_link": "飞控 AIR 链路",
    "field.command_policy": "命令策略",
    "field.start_block": "START 阻止原因",
    "field.last_command_result": "最近命令",
    "field.lock_state": "解锁状态",
    "field.pc_processing": "PC 处理状态",
    "field.gs_radio": "地面站 / 无线",
    "field.last_air_ack": "最近 AIR ACK",
    "field.mode": "模式",
    "field.state": "状态",
    "field.ready": "就绪",
    "field.current_face": "当前面",
    "field.six_face": "六面进度",
    "field.attitude": "姿态",
    "field.gnss_origin": "GNSS 原点",
    "field.baro_origin": "气压原点",
    "field.accel_mps2": "加速度 XYZ（m/s²）",
    "field.gyro_radps": "角速度 XYZ（rad/s）",
    "field.quat_raw": "四元数 raw/Q15",
    "field.quat_wxyz": "四元数 WXYZ",
    "field.euler_rpy_rad": "欧拉角 RPY（rad）",
    "field.position_usable": "定位可用",
    "field.origin_ready": "原点就绪",
    "field.start_reason": "当前不能 START 的原因：",
    "field.mission_time": "任务时间",
    "field.packet_loss": "丢包",
    "field.last_packet_age": "最近数据包年龄",
    "field.rssi": "RSSI",
    "field.snr": "SNR",
    "field.accel_xyz": "加速度 XYZ",
    "field.gyro_xyz": "角速度 XYZ",
    "field.quaternion": "四元数",
    "field.euler_rpy": "欧拉角 RPY",
    "field.velocity_enu": "速度 ENU",
    "field.position_enu": "位置 ENU",
    "button.refresh_ports": "刷新串口",
    "button.connect": "连接",
    "button.disconnect": "断开",
    "button.calibration": "开始 / 查看校准",
    "button.align_start": "开始初对准",
    "button.stop": "停止",
    "button.reset": "重置",
    "button.ping": "连通测试",
    "button.lock": "锁定",
    "button.unlock": "解锁",
    "button.start": "开始任务",
    "button.generate_sim": "生成模拟验证数据",
    "button.process_data": "处理数据",
    "button.open_logs": "打开日志目录",
    "button.open_data": "打开数据目录",
    "button.close": "关闭",
    "button.cal_start": "开始所选校准",
    "button.collect_face": "采集 {face}",
    "note.gnss_profile": "AIR Profile 0 不传输卫星数、HAcc/VAcc 或经纬度；本上位机不显示协议未提供的数据。",
    "common.yes": "是",
    "common.no": "否",
    "common.pass": "通过",
    "common.not_ready": "未就绪",
    "common.ready": "就绪",
    "common.wait": "等待",
    "common.normal": "正常",
    "common.backlog": "积压",
    "common.not_supported": "不支持",
    "common.locked": "已锁定",
    "common.unlocked": "已解锁",
    "common.unknown": "未知",
    "common.accepted": "已接受",
    "common.failed": "失败",
    "common.none": "—",
    "connection.not_connected": "未连接地面站",
    "connection.connecting": "正在连接 {endpoint}",
    "connection.connected": "地面站已连接：{detail}",
    "connection.disconnected": "地面站已断开：{detail}",
    "connection.error": "连接错误：{detail}",
    "capability.waiting": "等待 Capability",
    "capability.profile": "Profile {profile}，{accel:g} g / {gyro:g} dps",
    "capability.unsupported": "不支持的 AIR Profile（{profile}）",
    "capability.invalid_scale": "Capability 的 IMU 量程无效",
    "capability.invalid_policy": "Capability 的命令策略无效",
    "capability.error.UNSUPPORTED_PROFILE": "不支持的 AIR Profile",
    "capability.error.INVALID_IMU_FULL_SCALE": "Capability 的 IMU 量程无效",
    "capability.error.INVALID_COMMAND_POLICY": "Capability 的命令策略无效",
    "handshake.WAITING": "等待 Capability",
    "handshake.HANDSHAKING": "握手中",
    "handshake.ACKED": "已握手",
    "handshake.ERROR": "握手错误",
    "sensor.wait_capability_raw": "等待 Capability；raw={raw}",
    "sensor.quat_valid": "有效",
    "sensor.quat_invalid": "无效（raw=0）",
    "start.wait_capability": "等待 Capability 自动握手",
    "start.wait_pending": "等待 {command} ACK",
    "start.tooltip": "{reason}\n{hint}\n最近 ACK：{ack}",
    "radio.capability_priority": "Capability 自动握手优先，暂不发送人工命令",
    "radio.command_pending": "已有 AIR_CMD 等待 ACK，暂不发送新命令",
    "radio.command_not_allowed": "当前 Capability / Command Policy 不允许发送该 AIR 命令",
    "radio.command_tx": "{command} {action}，第 {attempt}/{total} 次",
    "radio.capability_tx": "自动 Capability ACK {action}：Cap#{cap_seq} / CMD#{cmd_seq}",
    "radio.capability_complete": "Capability 握手完成（{source}）",
    "radio.capability_timeout": "Capability ACK 超时；等待下一次 Capability 广播",
    "radio.air_ack_timeout": "AIR_CMD ACK 超时",
    "radio.start_confirmed": "START 已确认，任务开始",
    "radio.lock_confirmed": "LOCK 请求已确认；最终状态以 PREFLIGHT_STATUS 为准",
    "radio.unlock_confirmed": "UNLOCK 请求已确认；最终状态以 PREFLIGHT_STATUS 为准",
    "radio.calibration_accepted": "{command} 已接受；完成状态必须等待飞控上报",
    "radio.alignment_accepted": "{command} 已接受；Alignment 完成必须等待飞控上报",
    "radio.ack_ok": "{command} ACK：成功",
    "radio.already_locked": "飞控已处于 LOCKED",
    "radio.already_unlocked": "飞控已处于 UNLOCKED",
    "radio.ack_failed": "{command} 失败：{result}",
    "radio.start_blocked": "START 被阻止：{reason}",
    "radio.calibration_mode_unsupported": "飞控 Capability 未声明支持所选校准模式",
    "radio.calibration_face_invalid": "CAL_FACE 参数必须是 0..5",
    "radio.alignment_requires_calibration": "Calibration 尚未 READY，不能开始 Alignment",
    "ack.waiting": "等待 ACK：seq={seq} cmd={command}，第 {attempt}/{total} 次",
    "ack.timeout": "ACK 超时：seq={seq} cmd={command}，已发送 {attempts} 次",
    "ack.received": "ack_seq={seq} cmd={command} result={result}",
    "ack.received_unmatched_capability": "ack_seq={seq} cmd={command} result={result}；未匹配当前 Capability ACK",
    "ack.received_unmatched_command": "ack_seq={seq} cmd={command} result={result}；未匹配本机待应答命令",
    "gsp.ack": "type=0x{type:02X} result={result} detail={detail}",
    "cal.dialog.title": "校准",
    "cal.supported_modes": "飞控声明支持的模式",
    "cal.faces_title": "六面采集（ACK OK 仅代表请求已接受；完成状态来自飞控）",
    "cal.wait_status": "等待 Capability / PREFLIGHT_STATUS",
    "cal.guidance.one_face": "等待飞控自动采集；上位机不会发送 CAL_FACE。",
    "cal.guidance.six_face": "摆到对应面并保持静止，再点击该面的采集按钮。",
    "cal.guidance.none": "已选择 NONE；最终完成仍以 calibration_ready 为准。",
    "cal.guidance.select": "请选择 Capability 声明支持的校准模式。",
    "cal.status": "模式={mode}　状态={state}　当前面={face}　就绪={ready}\n{guidance}",
    "plot.velocity_e": "东向速度（m/s）",
    "plot.velocity_n": "北向速度（m/s）",
    "plot.velocity_u": "天向速度（m/s）",
    "plot.position_e": "东向位置（m）",
    "plot.position_n": "北向位置（m）",
    "plot.position_u": "天向位置（m）",
    "plot.mission_time": "任务时间 / s",
    "event.line": "{time_ms:>10} ms　{name}　arg0={arg0} arg1={arg1}",
    "event.gnss.usable": "定位可用",
    "event.gnss.unusable": "定位不可用",
    "event.face.passed": "通过",
    "event.face.failed": "失败",
    "event.detail.none": "",
    "event.detail.gnss": "{value}",
    "event.detail.face": "{face} {result}",
    "event.detail.calibration": "{state}",
    "event.detail.alignment": "{state}",
    "message.select_port": "请先选择串口。",
    "message.previous_session_stopping": "上一接收会话仍在安全停止和落盘，请稍后重试连接。",
    "message.log_open_failed": "无法创建会话日志：\n{error}",
    "message.connect_ground_station_first": "请先连接地面站串口。",
    "message.open_folder_failed": "无法打开文件夹：\n{folder}",
    "message.mission_sim_disabled": "任务进行中，已禁用高负载模拟数据生成。",
    "message.sim_success": "模拟验证数据生成成功：\n{path}",
    "message.sim_failed": "模拟验证数据生成失败：\n{error}",
    "message.mission_processing_disabled": "任务进行中，已禁用高负载后处理。",
    "message.choose_log": "选择要处理的数据日志",
    "message.log_filter": "JSONL 日志 (*.jsonl);;所有文件 (*.*)",
    "message.invalid_log": "请选择非空的 .jsonl 日志文件。",
    "message.already_processed": "该数据已经处理过，数据目录中已有对应结果。",
    "message.processing_running": "当前已有数据处理任务在运行。",
    "message.processing": "正在处理数据…",
    "message.processing_title": "数据处理",
    "message.processing_progress": "正在处理数据…\n{detail}",
    "message.processing_success": "数据处理成功：\n{path}",
    "message.processing_failed": "文件有问题，无法处理：\n{error}",
}


EN_US: dict[str, str] = {
    "app.title": "SilverStar Flight Controller Ground Station",
    "language.label": "Language:",
    "page.preflight": "Preflight",
    "page.flight": "Flight",
    "page.post_process": "Post Process",
    "camera.unlock": "Unlock View",
    "camera.lock": "Lock View",
    "camera.reset": "Reset View",
    "group.connection": "PC ↔ Ground Station Serial Connection",
    "group.system": "System",
    "group.calibration": "Calibration",
    "group.alignment": "Alignment",
    "group.sensor_preflight": "Sensor Data (PREFLIGHT_STATE)",
    "group.gnss": "GNSS",
    "group.preflight_commands": "Preflight Mission Controls",
    "group.important_status": "Important Status",
    "group.current_data": "Current Data",
    "group.event_history": "Event History (latest 200; JSONL keeps all)",
    "group.live_plots": "Live Plots (latest {seconds:g} seconds)",
    "group.post_process": "Post Process (complete data is always read from JSONL)",
    "field.port": "Port",
    "field.baudrate": "Baud Rate",
    "field.lifecycle": "Lifecycle",
    "field.system_ready": "System Ready",
    "field.selftest": "Self-test",
    "field.capability": "Capability",
    "field.air_link": "Flight Controller AIR",
    "field.command_policy": "Command Policy",
    "field.start_block": "START Block",
    "field.last_command_result": "Last Command",
    "field.lock_state": "Unlock State",
    "field.pc_processing": "PC Processing",
    "field.gs_radio": "Ground Station / Radio",
    "field.last_air_ack": "Last AIR ACK",
    "field.mode": "Mode",
    "field.state": "State",
    "field.ready": "Ready",
    "field.current_face": "Current Face",
    "field.six_face": "Six-face Progress",
    "field.attitude": "Attitude",
    "field.gnss_origin": "GNSS Origin",
    "field.baro_origin": "Barometer Origin",
    "field.accel_mps2": "Acceleration XYZ (m/s²)",
    "field.gyro_radps": "Angular Rate XYZ (rad/s)",
    "field.quat_raw": "Quaternion raw/Q15",
    "field.quat_wxyz": "Quaternion WXYZ",
    "field.euler_rpy_rad": "Euler RPY (rad)",
    "field.position_usable": "Position Usable",
    "field.origin_ready": "Origin Ready",
    "field.start_reason": "Why START is blocked:",
    "field.mission_time": "Mission Time",
    "field.packet_loss": "Packet Loss",
    "field.last_packet_age": "Last Packet Age",
    "field.rssi": "RSSI",
    "field.snr": "SNR",
    "field.accel_xyz": "Acceleration XYZ",
    "field.gyro_xyz": "Angular Rate XYZ",
    "field.quaternion": "Quaternion",
    "field.euler_rpy": "Euler RPY",
    "field.velocity_enu": "Velocity ENU",
    "field.position_enu": "Position ENU",
    "button.refresh_ports": "Refresh Ports",
    "button.connect": "Connect",
    "button.disconnect": "Disconnect",
    "button.calibration": "Start / View Calibration",
    "button.align_start": "Start Alignment",
    "button.stop": "Stop",
    "button.reset": "Reset",
    "button.ping": "Ping",
    "button.lock": "Lock",
    "button.unlock": "Unlock",
    "button.start": "Start Mission",
    "button.generate_sim": "Generate Validation Data",
    "button.process_data": "Process Data",
    "button.open_logs": "Open Logs Folder",
    "button.open_data": "Open Data Folder",
    "button.close": "Close",
    "button.cal_start": "Start Selected Calibration",
    "button.collect_face": "Collect {face}",
    "note.gnss_profile": "AIR Profile 0 does not carry satellite count, HAcc/VAcc, or coordinates; this application does not invent unavailable data.",
    "common.yes": "Yes",
    "common.no": "No",
    "common.pass": "Pass",
    "common.not_ready": "Not Ready",
    "common.ready": "Ready",
    "common.wait": "Wait",
    "common.normal": "Normal",
    "common.backlog": "Backlog",
    "common.not_supported": "Not Supported",
    "common.locked": "Locked",
    "common.unlocked": "Unlocked",
    "common.unknown": "Unknown",
    "common.accepted": "Accepted",
    "common.failed": "Failed",
    "common.none": "—",
    "connection.not_connected": "Ground Station not connected",
    "connection.connecting": "Connecting to {endpoint}",
    "connection.connected": "Ground Station connected: {detail}",
    "connection.disconnected": "Ground Station disconnected: {detail}",
    "connection.error": "Connection error: {detail}",
    "capability.waiting": "Waiting for Capability",
    "capability.profile": "Profile {profile}, {accel:g} g / {gyro:g} dps",
    "capability.unsupported": "Unsupported AIR Profile ({profile})",
    "capability.invalid_scale": "Capability contains an invalid IMU full scale",
    "capability.invalid_policy": "Capability contains an invalid command policy",
    "capability.error.UNSUPPORTED_PROFILE": "Unsupported AIR Profile",
    "capability.error.INVALID_IMU_FULL_SCALE": "Capability contains an invalid IMU full scale",
    "capability.error.INVALID_COMMAND_POLICY": "Capability contains an invalid command policy",
    "handshake.WAITING": "Waiting for Capability",
    "handshake.HANDSHAKING": "Handshaking",
    "handshake.ACKED": "Acknowledged",
    "handshake.ERROR": "Handshake Error",
    "sensor.wait_capability_raw": "Waiting for Capability; raw={raw}",
    "sensor.quat_valid": "valid",
    "sensor.quat_invalid": "invalid (raw=0)",
    "start.wait_capability": "Waiting for automatic Capability handshake",
    "start.wait_pending": "Waiting for {command} ACK",
    "start.tooltip": "{reason}\n{hint}\nLast ACK: {ack}",
    "radio.capability_priority": "The Capability handshake has priority; manual commands are paused",
    "radio.command_pending": "An AIR_CMD is waiting for ACK; a new command was not sent",
    "radio.command_not_allowed": "The current Capability / Command Policy does not allow this AIR command",
    "radio.command_tx": "{command} {action}, attempt {attempt}/{total}",
    "radio.capability_tx": "Automatic Capability ACK {action}: Cap#{cap_seq} / CMD#{cmd_seq}",
    "radio.capability_complete": "Capability handshake completed ({source})",
    "radio.capability_timeout": "Capability ACK timed out; waiting for the next Capability broadcast",
    "radio.air_ack_timeout": "AIR_CMD ACK timed out",
    "radio.start_confirmed": "START acknowledged; mission started",
    "radio.lock_confirmed": "LOCK acknowledged; PREFLIGHT_STATUS remains authoritative",
    "radio.unlock_confirmed": "UNLOCK acknowledged; PREFLIGHT_STATUS remains authoritative",
    "radio.calibration_accepted": "{command} accepted; wait for flight-controller completion state",
    "radio.alignment_accepted": "{command} accepted; wait for flight-controller Alignment state",
    "radio.ack_ok": "{command} ACK: OK",
    "radio.already_locked": "The flight controller is already LOCKED",
    "radio.already_unlocked": "The flight controller is already UNLOCKED",
    "radio.ack_failed": "{command} failed: {result}",
    "radio.start_blocked": "START blocked: {reason}",
    "radio.calibration_mode_unsupported": "Capability does not declare the selected calibration mode",
    "radio.calibration_face_invalid": "CAL_FACE must be in the range 0..5",
    "radio.alignment_requires_calibration": "Calibration must be READY before Alignment can start",
    "ack.waiting": "Waiting for ACK: seq={seq} cmd={command}, attempt {attempt}/{total}",
    "ack.timeout": "ACK timeout: seq={seq} cmd={command}, sent {attempts} times",
    "ack.received": "ack_seq={seq} cmd={command} result={result}",
    "ack.received_unmatched_capability": "ack_seq={seq} cmd={command} result={result}; does not match the pending Capability ACK",
    "ack.received_unmatched_command": "ack_seq={seq} cmd={command} result={result}; does not match a pending local command",
    "gsp.ack": "type=0x{type:02X} result={result} detail={detail}",
    "cal.dialog.title": "Calibration",
    "cal.supported_modes": "Modes Declared by Flight Controller",
    "cal.faces_title": "Six-face Collection (ACK OK only means accepted; completion comes from flight-controller state)",
    "cal.wait_status": "Waiting for Capability / PREFLIGHT_STATUS",
    "cal.guidance.one_face": "Wait for automatic flight-controller collection; the PC will not send CAL_FACE.",
    "cal.guidance.six_face": "Place the unit on the requested face, keep it still, then click that face.",
    "cal.guidance.none": "NONE is selected; final completion still requires calibration_ready.",
    "cal.guidance.select": "Select a calibration mode declared by Capability.",
    "cal.status": "Mode={mode}  State={state}  Current={face}  Ready={ready}\n{guidance}",
    "plot.velocity_e": "Velocity E (m/s)",
    "plot.velocity_n": "Velocity N (m/s)",
    "plot.velocity_u": "Velocity U (m/s)",
    "plot.position_e": "Position E (m)",
    "plot.position_n": "Position N (m)",
    "plot.position_u": "Position U (m)",
    "plot.mission_time": "Mission Time / s",
    "event.line": "{time_ms:>10} ms  {name}  arg0={arg0} arg1={arg1}",
    "event.gnss.usable": "Position Usable",
    "event.gnss.unusable": "Position Unusable",
    "event.face.passed": "Passed",
    "event.face.failed": "Failed",
    "event.detail.none": "",
    "event.detail.gnss": "{value}",
    "event.detail.face": "{face} {result}",
    "event.detail.calibration": "{state}",
    "event.detail.alignment": "{state}",
    "message.select_port": "Select a serial port first.",
    "message.previous_session_stopping": "The previous receive session is still stopping and flushing safely. Try again shortly.",
    "message.log_open_failed": "Unable to create the session log:\n{error}",
    "message.connect_ground_station_first": "Connect the Ground Station serial port first.",
    "message.open_folder_failed": "Unable to open the folder:\n{folder}",
    "message.mission_sim_disabled": "High-load validation-data generation is disabled during a mission.",
    "message.sim_success": "Validation data generated successfully:\n{path}",
    "message.sim_failed": "Validation-data generation failed:\n{error}",
    "message.mission_processing_disabled": "High-load post-processing is disabled during a mission.",
    "message.choose_log": "Choose a Data Log",
    "message.log_filter": "JSONL logs (*.jsonl);;All files (*.*)",
    "message.invalid_log": "Select a non-empty .jsonl log file.",
    "message.already_processed": "This log already has a result in the data folder.",
    "message.processing_running": "A data-processing task is already running.",
    "message.processing": "Processing data…",
    "message.processing_title": "Data Processing",
    "message.processing_progress": "Processing data…\n{detail}",
    "message.processing_success": "Data processing completed:\n{path}",
    "message.processing_failed": "The file could not be processed:\n{error}",
}


ZH_CN.update(
    {
        "button.details": "详情",
        "button.calibration_start": "开始校准",
        "button.calibration_restart": "重新校准",
        "button.cal_restart": "重新开始所选校准",
        "button.recollect_face": "重新采集 {face}",
        "button.start_waiting": "等待 START 确认…",
        "dialog.link_details.title": "链路详情",
        "group.mission_state": "火箭当前状态",
        "field.current_issue": "当前提示",
        "field.alignment_hint": "对准提示",
        "field.mission_state": "当前任务状态",
        "field.last_key_event": "最近关键事件",
        "field.event_elapsed": "距该事件",
        "field.parachute_status": "回收 / 降落伞",
        "alignment.stale.hint": "检测到对准后移动，请重新执行初对准",
        "radio.alignment_stale": "检测到对准后移动，请重新执行初对准",
        "diagnostic.face_issue": "{face}：{reason}",
        "cal.face.completed_tooltip": "已完成，可重新采集",
        "cal.face.collect_tooltip": "点击开始采集此面",
        "cal.collecting_wait": "正在采集 {face}，请等待完成",
        "cal.checking_wait": "正在检查 {face}，请等待完成",
        "cal.collecting_wait_unknown": "正在采集，请等待完成",
        "start.ready": "可以 START",
        "start.cannot": "不能 START：{reason}",
        "start.pending": "START 请求已发送，等待飞控确认…",
        "start.mission_started": "任务已经开始",
        "start.busy_retry": "START 暂时忙，请稍后重试",
        "start.failed_retry": "START 被飞控拒绝：{reason}；可在条件恢复后重试",
        "start.timeout_retry": "START 确认超时，可重试",
        "start.other_pending": "不能 START：正在等待 {command}",
        "start.block.unlock": "需要解锁",
        "start.block.calibration": "校准未完成",
        "start.block.alignment": "初对准未完成",
        "start.block.system": "系统未就绪",
        "start.block.capability": "Capability 握手未完成",
        "start.block.busy": "飞控忙",
        "start.in_progress_short": "START 处理中",
        "start.ack_busy_short": "START ACK：飞控忙",
        "radio.start_pending": "START 请求已发送，等待飞控确认…",
        "radio.start_in_progress": "START 请求正在处理中；未重复发送",
        "radio.start_busy": "START 暂时忙，请稍后重试",
        "radio.start_failed": "START 被飞控拒绝：{result}",
        "radio.start_timeout": "START ACK 超时；已恢复操作，可重试",
        "radio.calibration_recovered": "{command} 已由 {source} 确认执行；本地 pending 已恢复",
        "radio.calibration_timeout": "{command} ACK 超时；已恢复校准操作入口",
        "mission.no_key_event": "尚无关键任务事件",
        "mission.elapsed": "{seconds:.1f} 秒",
        "mission.parachute_deployed": "降落伞已展开",
        "mission.parachute_not_deployed": "未收到降落伞展开事件",
        "air_link.not_detected": "未发现飞控",
        "air_link.downlink_wait": "AIR下行正常 · 等待握手",
        "air_link.handshaking": "握手中",
        "air_link.connected": "已连接",
        "air_link.unsupported": "协议不兼容",
        "air_link.error": "链路异常",
        "link_details.body": "Capability / AIR 握手\n"
        "Profile / IMU 量程：{profile} / {accel} g / {gyro} dps\n"
        "校准模式掩码 / 对准源掩码：{calibration_mask} / {alignment_mask}\n"
        "命令策略：{policy}\n"
        "握手状态：{handshake_state}\n"
        "最新 Capability seq：{cap_seq}\n"
        "已接受 Capability seq：{accepted_cap_seq}\n"
        "Capability ACK CMD seq：{cmd_seq}\n"
        "ACK 尝试次数：{attempts}\n"
        "GSP AIR_TX 请求数：{requests}\n"
        "串口写入次数 / 字节数：{serial_writes} / {serial_bytes}\n"
        "GSP ACK 成功 / 失败：{gsp_ok} / {gsp_fail}\n"
        "最近 GSP ACK：{gsp_result}\n"
        "最近 AIR ACK / 接收数：{air_result} / {air_ack_rx}\n"
        "PREFLIGHT_STATUS capability_acked: {pstatus}\n"
        "ACK 来源 AIR / PREFLIGHT_STATUS：{by_air_ack} / {by_pstatus}\n"
        "重复或过期 Capability：{duplicates}\n"
        "最近握手错误：{error}\n\n"
        "地面站 / 无线\n"
        "地面站状态 / 无线状态：{gs_state} / {radio_state}\n"
        "地面站 TX / RX / CRC：{gs_tx} / {gs_rx} / {gs_crc}\n"
        "RSSI / SNR：{rssi} / {snr}\n\n"
        "PC 接收 / 解析 / 日志\n{receive_health}",
    }
)

EN_US.update(
    {
        "button.details": "Details",
        "button.calibration_start": "Start Calibration",
        "button.calibration_restart": "Restart Calibration",
        "button.cal_restart": "Restart Selected Calibration",
        "button.recollect_face": "Recollect {face}",
        "button.start_waiting": "Waiting for START confirmation…",
        "dialog.link_details.title": "Link Details",
        "group.mission_state": "Mission State",
        "field.current_issue": "Current Issue",
        "field.alignment_hint": "Alignment Guidance",
        "field.mission_state": "Current Mission State",
        "field.last_key_event": "Last Key Event",
        "field.event_elapsed": "Time Since Event",
        "field.parachute_status": "Recovery / Parachute",
        "alignment.stale.hint": "Movement detected after alignment; run alignment again",
        "radio.alignment_stale": "Movement detected after alignment; run alignment again",
        "diagnostic.face_issue": "{face}: {reason}",
        "cal.face.completed_tooltip": "Completed; click to recollect",
        "cal.face.collect_tooltip": "Click to collect this face",
        "cal.collecting_wait": "Collecting {face}, please wait",
        "cal.checking_wait": "Checking {face}, please wait",
        "cal.collecting_wait_unknown": "Collecting, please wait",
        "start.ready": "Ready to START",
        "start.cannot": "Cannot START: {reason}",
        "start.pending": "START request sent; waiting for flight controller confirmation…",
        "start.mission_started": "Mission has started",
        "start.busy_retry": "START busy; try again shortly",
        "start.failed_retry": "START rejected: {reason}; retry after conditions recover",
        "start.timeout_retry": "START confirmation timed out; retry is available",
        "start.other_pending": "Cannot START: waiting for {command}",
        "start.block.unlock": "Unlock required",
        "start.block.calibration": "Calibration incomplete",
        "start.block.alignment": "Alignment incomplete",
        "start.block.system": "System not ready",
        "start.block.capability": "Capability handshake incomplete",
        "start.block.busy": "Flight controller busy",
        "start.in_progress_short": "START in progress",
        "start.ack_busy_short": "START ACK: controller busy",
        "radio.start_pending": "START request sent; waiting for flight controller confirmation…",
        "radio.start_in_progress": "START request is already in progress; no duplicate was sent",
        "radio.start_busy": "START busy; try again shortly",
        "radio.start_failed": "START rejected by flight controller: {result}",
        "radio.start_timeout": "START ACK timed out; controls recovered and retry is available",
        "radio.calibration_recovered": "{command} execution confirmed by {source}; local pending recovered",
        "radio.calibration_timeout": "{command} ACK timed out; calibration controls recovered",
        "mission.no_key_event": "No key mission event received",
        "mission.elapsed": "{seconds:.1f} s",
        "mission.parachute_deployed": "Parachute Deployed",
        "mission.parachute_not_deployed": "No parachute deployment event received",
        "air_link.not_detected": "Flight Controller Not Detected",
        "air_link.downlink_wait": "AIR Downlink OK · Waiting Handshake",
        "air_link.handshaking": "Handshaking",
        "air_link.connected": "Connected",
        "air_link.unsupported": "Unsupported Profile",
        "air_link.error": "Link Error",
        "link_details.body": "Capability / AIR Handshake\n"
        "Profile / IMU scales: {profile} / {accel} g / {gyro} dps\n"
        "Calibration mode mask / alignment source mask: {calibration_mask} / {alignment_mask}\n"
        "Command policy: {policy}\n"
        "Handshake state: {handshake_state}\n"
        "Latest Capability seq: {cap_seq}\n"
        "Accepted Capability seq: {accepted_cap_seq}\n"
        "Capability ACK CMD seq: {cmd_seq}\n"
        "ACK attempts: {attempts}\n"
        "GSP AIR_TX requests: {requests}\n"
        "Serial writes / bytes: {serial_writes} / {serial_bytes}\n"
        "GSP ACK OK / FAIL: {gsp_ok} / {gsp_fail}\n"
        "Last GSP ACK: {gsp_result}\n"
        "Last AIR ACK / count: {air_result} / {air_ack_rx}\n"
        "PREFLIGHT_STATUS capability_acked: {pstatus}\n"
        "ACK source AIR / PREFLIGHT_STATUS: {by_air_ack} / {by_pstatus}\n"
        "Duplicate or stale Capability: {duplicates}\n"
        "Last handshake error: {error}\n\n"
        "Ground Station / Radio\n"
        "GS state / Radio state: {gs_state} / {radio_state}\n"
        "GS TX / RX / CRC: {gs_tx} / {gs_rx} / {gs_crc}\n"
        "RSSI / SNR: {rssi} / {snr}\n\n"
        "PC Receive / Parser / Logger\n{receive_health}",
    }
)


_ENUM_KEYS: dict[str, dict[str, tuple[str, str]]] = {
    "command_policy": {
        "PREFLIGHT_ONLY": ("仅预飞阶段允许命令", "Preflight Only"),
        "MISSION_ALLOWED": ("任务阶段也允许命令", "Mission Allowed"),
        "UNKNOWN": ("等待 Capability", "Waiting for Capability"),
    },
    "gsp_ack_result": {
        "OK": ("成功", "OK"),
        "BAD_CRC": ("CRC 错误", "Bad CRC"),
        "BAD_LEN": ("长度错误", "Bad Length"),
        "BAD_TYPE": ("类型错误", "Bad Type"),
        "BAD_PARAM": ("参数错误", "Bad Parameter"),
        "BUSY": ("忙", "Busy"),
    },
    "lifecycle": {
        "BOOT": ("启动", "Boot"),
        "SELF_TEST": ("自检", "Self-test"),
        "PREFLIGHT": ("预飞行", "Preflight"),
        "READY": ("就绪", "Ready"),
        "FLIGHT": ("飞行", "Flight"),
        "RECOVERY": ("回收", "Recovery"),
        "LANDED": ("已着陆", "Landed"),
        "POSTFLIGHT": ("飞行后", "Postflight"),
        "FAULT": ("故障", "Fault"),
    },
    "calibration_state": {
        "IDLE": ("空闲", "Idle"),
        "WAIT_FACE": ("等待放置", "Waiting for Face"),
        "COLLECTING": ("采集中", "Collecting"),
        "CHECKING": ("检查中", "Checking"),
        "READY": ("就绪", "Ready"),
        "FAILED": ("失败", "Failed"),
    },
    "calibration_mode": {
        "NONE": ("无需实物校准", "None"),
        "ONE_FACE": ("单面校准", "One-face"),
        "SIX_FACE": ("六面校准", "Six-face"),
        "NOT_SELECTED": ("未选择", "Not Selected"),
    },
    "alignment_state": {
        "IDLE": ("空闲", "Idle"),
        "COLLECTING": ("采集中", "Collecting"),
        "CHECKING": ("检查中", "Checking"),
        "READY": ("就绪", "Ready"),
        "FAILED": ("失败", "Failed"),
    },
    "status": {
        "BOOT": ("启动", "Boot"),
        "SELFTEST_COMPLETE": ("自检完成", "Self-test Complete"),
        "MISSION_START": ("任务开始", "Mission Start"),
        "LAUNCH": ("发射", "Launch"),
        "PARACHUTE_DEPLOY": ("降落伞展开", "Parachute Deploy"),
        "LANDING": ("着陆", "Landing"),
        "LOCKED": ("已锁定", "Locked"),
        "UNLOCKED": ("已解锁", "Unlocked"),
        "GNSS_POSITION": ("GNSS 定位", "GNSS Position"),
        "ALIGNMENT": ("初对准", "Alignment"),
        "CALIBRATION": ("校准", "Calibration"),
        "CALIBRATION_FACE": ("校准面", "Calibration Face"),
    },
    "ack_result": {
        "OK": ("成功", "OK"),
        "BAD_LEN": ("长度错误", "Bad Length"),
        "BAD_CMD": ("命令错误", "Bad Command"),
        "BAD_TOKEN": ("令牌错误", "Bad Token"),
        "BUSY": ("忙", "Busy"),
        "REJECTED": ("已拒绝", "Rejected"),
        "BAD_STATE": ("状态错误", "Bad State"),
        "LOCKED_REQUIRED": ("需要锁定", "Locked Required"),
        "ALREADY_LOCKED": ("已经锁定", "Already Locked"),
        "ALREADY_UNLOCKED": ("已经解锁", "Already Unlocked"),
        "CAPABILITY_REQUIRED": ("需要完成能力握手", "Capability Required"),
        "CALIBRATION_REQUIRED": ("需要完成校准", "Calibration Required"),
        "ALIGNMENT_REQUIRED": ("需要完成初对准", "Alignment Required"),
        "SYSTEM_NOT_READY": ("系统未就绪", "System Not Ready"),
        "ATTITUDE_NOT_READY": ("姿态未就绪", "Attitude Not Ready"),
        "ATTITUDE_INVALID": ("姿态无效", "Attitude Invalid"),
        "ATTITUDE_STALE": ("姿态过期", "Attitude Stale"),
        "ORIGIN_FAILED": ("原点建立失败", "Origin Failed"),
        "NAVIGATION_FAILED": ("导航失败", "Navigation Failed"),
        "QUEUE_FAILED": ("队列失败", "Queue Failed"),
        "BAD_PARAM": ("参数错误", "Bad Parameter"),
        "HOOKS_UNAVAILABLE": ("准备接口不可用", "Hooks Unavailable"),
        "PREPARE_FAILED": ("任务准备失败", "Prepare Failed"),
    },
    "gs_state": {
        "IDLE": ("空闲", "Idle"),
        "INIT_OK": ("初始化完成", "Initialized"),
        "RX_MODE": ("接收模式", "Receive Mode"),
        "TX_MODE": ("发送模式", "Transmit Mode"),
        "ERROR": ("错误", "Error"),
    },
    "radio_state": {
        "NOT_INIT": ("未初始化", "Not Initialized"),
        "READY": ("就绪", "Ready"),
        "RX": ("接收", "Receiving"),
        "TX": ("发送", "Transmitting"),
        "BUSY": ("忙", "Busy"),
    },
}

_ENUM_KEYS["ack_result"]["LOCKED_REQUIRED"] = ("需要解锁", "Unlock Required")
_ENUM_KEYS["alignment_state"]["STALE"] = ("初对准已失效", "Alignment Stale")
_ENUM_KEYS["status"]["CALIBRATION_DIAGNOSTIC"] = (
    "校准诊断",
    "Calibration Diagnostic",
)
_ENUM_KEYS["calibration_diagnostic_reason"] = {
    "NONE": ("无", "None"),
    "NO_STREAM": ("等待惯性数据", "Waiting for inertial data"),
    "GYRO_MOVING": ("请保持飞控静止", "Keep the flight controller still"),
    "ACCEL_MAGNITUDE": (
        "比力模长不符合静止条件",
        "Specific-force magnitude is outside the stationary range",
    ),
    "GRAVITY_DIRECTION": (
        "当前重力方向与所选面不符",
        "Current gravity direction does not match the selected face",
    ),
    "VARIANCE": (
        "采样波动过大，正在重新采集",
        "Sample variance is too high; recollecting",
    ),
    "SAMPLE_GAP": (
        "数据存在间断，正在重新采集",
        "A data gap was detected; recollecting",
    ),
}
_ENUM_KEYS["mission_phase"] = {
    "PRE_START": ("任务前", "Pre-start"),
    "MISSION_ACTIVE": ("任务已开始 / 等待发射", "Mission Active / Waiting Launch"),
    "IN_FLIGHT": ("飞行中", "In Flight"),
    "RECOVERY": ("回收中 / 降落伞已展开", "Recovery / Parachute Deployed"),
    "LANDED": ("已着陆", "Landed"),
}


class I18n:
    SETTINGS_ORGANIZATION = "SilverStar"
    SETTINGS_APPLICATION = "SS1GroundStation"
    SETTINGS_LANGUAGE_KEY = "language"

    def __init__(self, settings: QSettings | None = None) -> None:
        self.settings = settings or QSettings(
            self.SETTINGS_ORGANIZATION,
            self.SETTINGS_APPLICATION,
        )
        raw = str(self.settings.value(self.SETTINGS_LANGUAGE_KEY, Language.ZH_CN.value))
        try:
            self.language = Language(raw)
        except ValueError:
            self.language = Language.ZH_CN

    def set_language(self, language: Language | str) -> bool:
        selected = language if isinstance(language, Language) else Language(str(language))
        if selected is self.language:
            return False
        self.language = selected
        self.settings.setValue(self.SETTINGS_LANGUAGE_KEY, selected.value)
        self.settings.sync()
        return True

    def tr(self, key: str, **params: Any) -> str:
        table = ZH_CN if self.language is Language.ZH_CN else EN_US
        template = table.get(key, ZH_CN.get(key, key))
        try:
            return template.format(**params)
        except (KeyError, ValueError):
            return template

    def enum(self, namespace: str, canonical_name: str) -> str:
        values = _ENUM_KEYS.get(namespace, {}).get(str(canonical_name))
        if values is None:
            return str(canonical_name)
        return values[0] if self.language is Language.ZH_CN else values[1]

    def format_message(self, message: Any) -> str:
        key = getattr(message, "key", "")
        params: Mapping[str, Any] = getattr(message, "params", {})
        resolved = {
            name: (
                self.enum(value.namespace, value.canonical_name)
                if isinstance(value, EnumParam)
                else value
            )
            for name, value in params.items()
        }
        return self.tr(str(key), **resolved) if key else "—"


def translation_keys_match() -> bool:
    return set(ZH_CN) == set(EN_US)


__all__ = [
    "EN_US",
    "EnumParam",
    "I18n",
    "Language",
    "ZH_CN",
    "translation_keys_match",
]
